var searchData=
[
  ['event',['event',['../structzmq__event__t.html#a82b19531e51d234ec37b8562d0eb30ad',1,'zmq_event_t']]]
];
