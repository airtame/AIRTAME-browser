var searchData=
[
  ['bind',['bind',['../classzmq_1_1socket__t.html#a77c71eec103238be911d5d7ada2ec4cc',1,'zmq::socket_t::bind(std::string const &amp;addr)'],['../classzmq_1_1socket__t.html#af249fa783692a737d5e206cfad20a6ed',1,'zmq::socket_t::bind(const char *addr_)']]],
  ['browserapplication',['BrowserApplication',['../classBrowserApplication.html#add263a9cbbb2ca108854df396d89eb8a',1,'BrowserApplication']]]
];
