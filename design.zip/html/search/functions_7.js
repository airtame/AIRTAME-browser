var searchData=
[
  ['isrunning',['isRunning',['../classBrowserApplication.html#ac3f738fef1d7672cbae68a34bf7676df',1,'BrowserApplication']]]
];
