var searchData=
[
  ['browserapplication',['BrowserApplication',['../classBrowserApplication.html',1,'']]]
];
