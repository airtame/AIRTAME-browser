var searchData=
[
  ['getsockopt',['getsockopt',['../classzmq_1_1socket__t.html#ab13f8833a7cf8bccc966bab379895cad',1,'zmq::socket_t::getsockopt(int option_, void *optval_, size_t *optvallen_)'],['../classzmq_1_1socket__t.html#af0516844a30cb664b1aef66633c0e0e8',1,'zmq::socket_t::getsockopt(int option_)']]]
];
