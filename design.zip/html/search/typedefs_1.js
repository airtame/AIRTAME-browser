var searchData=
[
  ['pollitem_5ft',['pollitem_t',['../namespacezmq.html#afae32df5376640a84a10f2fd3ba2fee9',1,'zmq']]]
];
