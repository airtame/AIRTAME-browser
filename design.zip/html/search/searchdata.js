var indexSectionsWithContent =
{
  0: "abcdefgijmnopqrstuvwz~",
  1: "abceimqsuwz",
  2: "uz",
  3: "abceimoruwz",
  4: "abcdefgijmnopqrsuvwz~",
  5: "adempqsvw",
  6: "fp",
  7: "ms",
  8: "iqtz",
  9: "a"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "typedefs",
  7: "related",
  8: "defines",
  9: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Typedefs",
  7: "Friends",
  8: "Macros",
  9: "Pages"
};

