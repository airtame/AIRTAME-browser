var searchData=
[
  ['path_5fto_5fsocket_5ffile',['path_to_socket_file',['../zmqserver_8cpp.html#a2fabbabdf72bd1d3ffb1c929a5cb95e2',1,'zmqserver.cpp']]]
];
