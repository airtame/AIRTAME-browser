var searchData=
[
  ['unbind',['unbind',['../classzmq_1_1socket__t.html#a7387f3291b022bfcb8ca25720d1d5d82',1,'zmq::socket_t::unbind(std::string const &amp;addr)'],['../classzmq_1_1socket__t.html#a1cfc4149368e4959a4c48ce42e7faae8',1,'zmq::socket_t::unbind(const char *addr_)']]]
];
