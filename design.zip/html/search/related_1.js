var searchData=
[
  ['socket_5ft',['socket_t',['../classzmq_1_1message__t.html#a3dd023235afa636de27f408c071365ac',1,'zmq::message_t::socket_t()'],['../classzmq_1_1context__t.html#a3dd023235afa636de27f408c071365ac',1,'zmq::context_t::socket_t()']]]
];
