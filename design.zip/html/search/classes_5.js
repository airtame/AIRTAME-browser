var searchData=
[
  ['message_5ft',['message_t',['../classzmq_1_1message__t.html',1,'zmq']]],
  ['monitor_5ft',['monitor_t',['../classzmq_1_1monitor__t.html',1,'zmq']]]
];
