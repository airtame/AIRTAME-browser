var searchData=
[
  ['mainwindow',['mainWindow',['../classBrowserApplication.html#a03f2cfe87af706712de12421861c3ec6',1,'BrowserApplication']]]
];
