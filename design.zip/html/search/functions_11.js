var searchData=
[
  ['version',['version',['../namespacezmq.html#af04cbb1885b768c4ce23615883367c20',1,'zmq']]]
];
