var searchData=
[
  ['io_5fthreads_5fnr',['IO_THREADS_NR',['../zmqserver_8cpp.html#a31bfdb96d239143af10a2f9f5a96cd4a',1,'zmqserver.cpp']]]
];
