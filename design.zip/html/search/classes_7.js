var searchData=
[
  ['socket_5ft',['socket_t',['../classzmq_1_1socket__t.html',1,'zmq']]]
];
